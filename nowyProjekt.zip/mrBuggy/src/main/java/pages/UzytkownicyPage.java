package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import helpers.helper;

public class UzytkownicyPage {

	private WebDriver driver;

	@FindBy(xpath = "//*[@class='button_link']")
	private WebElement buttonDodajUzytkownika;

	@FindBy(xpath = "//*[@id='firstname']")
	private WebElement inputImie;

	@FindBy(xpath = "//*[@id='lastname']")
	private WebElement inputNazwisko;

	@FindBy(xpath = "//*[@id='email']")
	private WebElement inputEmail;

	@FindBy(xpath = "//*[@id='save']")
	private WebElement buttonSave;

	public UzytkownicyPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);

	}

	public void getDodajUzytkownika() {
		this.buttonDodajUzytkownika.isDisplayed();
	}

	public void clickDodajUzytkownika() {
		this.buttonDodajUzytkownika.click();
	}

	public void fillUzytkownicy() {
		this.inputImie.click();
		String name = helper.generateRandomName();
		this.inputImie.sendKeys(name);
		this.inputNazwisko.click();
		String nazwisko = helper.generateRandomName();
		this.inputNazwisko.sendKeys(nazwisko);
		this.inputEmail.click();
		String email = helper.generateRandomName() + "@gmail.com";
		this.inputEmail.sendKeys(email);

	}

	public void clickButtonSave() {
		this.buttonSave.click();

	}
}
