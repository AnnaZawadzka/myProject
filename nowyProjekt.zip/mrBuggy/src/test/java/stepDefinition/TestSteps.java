package stepDefinition;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import helpers.helper;
import pages.AdministrationPage;
import pages.LoginPage;
import pages.MainPage;
import pages.ProjectPage;
import pages.UzytkownicyPage;

public class TestSteps {

	public static WebDriver driver;
	public MainPage mainPage;
	public LoginPage loginPage;
	public AdministrationPage administrationPage;
	public ProjectPage projectPage;
	public UzytkownicyPage uzytkownicyPage;
	public String myname;
	public String myprefix;

	
	
	public TestSteps(TestContext context)
	{
		driver = context.getDriver();
		mainPage = new MainPage(driver);
		loginPage = new LoginPage(driver);
		administrationPage = new AdministrationPage(driver);
		projectPage = new ProjectPage(driver);
		uzytkownicyPage = new UzytkownicyPage(driver);
		 
	}
	
	
	// public void setUp() throws Exception {
	// System.setProperty("webdriver.chrome.driver","seleniumUtils/chromedriver.exe");
	// driver = new ChromeDriver();
	// mainPage = new MainPage(driver);
	// loginPage = new LoginPage(driver);
	// administrationPage =new AdministrationPage(driver);
	// projectPage = new ProjectPage(driver);
	// }

	@Given("^I am logged on the main page$")
	public void i_am_logged_on_the_main_page() throws Throwable {

		loginPage.open();
		loginPage.logIn("admin@tc2014.pl", "12qwAS");

	}

	// @Given("^I add the new project$")
	// public void i_add_the_new_project() throws Throwable {
	//
	// administrationPage =new AdministrationPage(driver);
	//
	// mainPage.getAdministrationButton();
	// administrationPage.getAddProjectButton();
	// String name = helper.generateRandomString();
	// String prefix = helper.generateRandomString();
	// administrationPage.setName(name);
	// administrationPage.setPrefix(prefix);
	// administrationPage.getButtonSave();
	//
	//
	// }

	@Given("^I add the new project with name prefix$")
	public void i_add_the_new_project_with_name_prefix() throws Throwable {

	
		String name = helper.generateRandomString();
		String prefix = helper.generateRandomString();

		myname = name;
		myprefix = prefix;
		mainPage.getAdministrationButton();
		administrationPage.getAddProjectButton();
		administrationPage.setName(myname);
		administrationPage.setPrefix(myprefix);
		administrationPage.getButtonSave();

	}

	@When("^I search for the added project$")
	public void i_search_for_the_added_project() throws Throwable {

		administrationPage.searchForProject(myname);

	}

	@Then("^The project is found in the search results$")
	public void the_project_is_found_in_the_search_results() throws Throwable {
		administrationPage.openProject();

	}

	@Then("^The data is correct$")
	public void the_data_is_correct() throws Throwable {

		

		Assert.assertEquals(projectPage.checkHeader().getText(), "WŁAŚCIWOŚCI PROJEKTU");
		Assert.assertEquals(projectPage.checkName().getText(), myname);
		Assert.assertEquals(projectPage.checkPrefix().getText(), myprefix);

	}
	
	@Given("^I am on Uzytkownicy tab$")
	public void i_am_on_Uzytkownicy_tab() throws Throwable {
		mainPage.getAdministrationButton();
		administrationPage.clickUzytkownicy();
		uzytkownicyPage.getDodajUzytkownika();
		  
	}

	@Given("^I select CTA Dodaj Uzytkownika$")
	public void i_select_CTA_Dodaj_Uzytkownika() throws Throwable {
	  uzytkownicyPage.clickDodajUzytkownika();
	}

	@Given("^I fill all mandatory fields$")
	public void i_fill_all_mandatory_fields() throws Throwable {
	    uzytkownicyPage.fillUzytkownicy();
	}

	@When("^I select CTA Zapisz$")
	public void i_select_CTA_Zapisz() throws Throwable {

		uzytkownicyPage.clickButtonSave();
	}

	
	@Given("^I am on Uzytkowicy page$")
	public void i_am_on_Uzytkowicy_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I find one of created users in \"([^\"]*)\"$")
	public void i_find_one_of_created_users_in(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


	@Given("^I select CTA Edytuj$")
	public void i_select_CTA_Edytuj() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I change \"([^\"]*)\"$")
	public void i_change(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^The \"([^\"]*)\" is visible in \"([^\"]*)\"$")
	public void the_is_visible_in(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
