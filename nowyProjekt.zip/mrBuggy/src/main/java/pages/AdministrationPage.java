package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class AdministrationPage {
	
	
	private WebDriver driver; 
	
	@FindBy(xpath = "//*[@class='button_link_li']//a")
	private WebElement buttonAddProject;
	
	@FindBy(xpath = "//input[@id='name']")
	private WebElement textFieldName;
	
	@FindBy(xpath = "//input[@id='prefix']")
	private WebElement textFieldPrefix;
	
	@FindBy(xpath = "//*[@id='save']")
	private WebElement buttonSave;
	
	@FindBy(xpath = "//*[@id='j_info_box']")
	private WebElement popupProjectAdded;
	
	@FindBy(xpath = "//input[@id='search']")
	private WebElement textBoxSearch;
	
	@FindBy(xpath = "//button[@id='j_filterButton']")
	private WebElement buttonSearch;
	
	@FindBy(xpath = "//li[@class='item4']/a")
	private WebElement myProject;
	
	//@FindBy(xpath = "*//a[contains(@href,'users')]/@href")
	
	@FindBy(xpath = "//*[@id='wrapper']/ul/li[3]/a")
	private WebElement buttonUzytkownicy;

	
	
	//*[@id="save"]

	public AdministrationPage(WebDriver driver) {
		this.driver = driver;
		  PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
		  
		  
	}
	
	 public void getAddProjectButton ()
	{
		this.buttonAddProject.click();
	}
	
	 public WebElement getPrefix ()
		{
		 return textFieldPrefix;
		}
	 
	 public void setName (String name)
		{
			this.textFieldName.click();
			this.textFieldName.sendKeys(name);
		}
		
	 public void setPrefix (String name)
		{
			this.textFieldPrefix.click();
			this.textFieldPrefix.sendKeys(name);
		}
	 
	 public void getButtonSave ()
		{
			this.buttonSave.click();
		}
	 


	 public WebElement getpopupProjectAdded()
	 {
		 
		 return popupProjectAdded;
	 }
	 
	 public void searchForProject (String projectName)
		{
		this.textBoxSearch.click();
	 	this.textBoxSearch.sendKeys(projectName);
		this.buttonSearch.click();
		}
	 
	 public void openProject ()
		{
		this.myProject.click();
	 	
		}
	 
	 public void clickUzytkownicy ()
		{
		this.buttonUzytkownicy.click();
	 	
		}
	 
	 
	 
}