package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class ProjectPage {
	
	private WebDriver driver; 
	
	@FindBy(xpath = "//*[@id='content']/article/h1")
	private WebElement fieldHeader;
	
	@FindBy(xpath = "//*[@class='content_label_title']")
	private WebElement fieldName;
	
	@FindBy(xpath = "//*[contains(text(),'Prefiks')]/following::div[1]")
	private WebElement fieldPrefix;

//	@FindBy(xpath = "//*[contains(text(),'Data utworzenia')]/following::div[1]")
//	private WebElement fieldDate;
	
	public ProjectPage(WebDriver driver) 
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
		this.driver = driver;

	}
	
	public WebElement checkHeader ()
	{
		return fieldHeader;
	}
	
	
	public WebElement checkName ()
	{
		return fieldName;
	}
	
	public WebElement checkPrefix ()
	{
		return fieldPrefix;
	}	

}
