package seleniumTest;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import helpers.helper;
import pages.AdministrationPage;
import pages.LoginPage;
import pages.MainPage;
import pages.ProjectPage;

public class FirstTest {

	public static WebDriver driver;
	public MainPage mainPage;
	public LoginPage loginPage;
	public AdministrationPage administrationPage;
	public ProjectPage projectPage;
	
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception 	{
		driver.close(); 
	}

	@Before
	public void setUp() throws Exception 	{
		System.setProperty("webdriver.chrome.driver","seleniumUtils/chromedriver.exe");
		driver = new ChromeDriver();
		mainPage = new MainPage(driver);
		loginPage = new LoginPage(driver);
		administrationPage =new  AdministrationPage(driver);
		projectPage = new  ProjectPage(driver);
	}

	@After
	public void tearDown() throws Exception 	{
		driver.manage().deleteAllCookies();
	}

//	@Test
//	public void loginTest() {
//		loginPage.open();
//	    loginPage.logIn("admin@tc2014.pl", "12qwAS");
//	    Assert.assertEquals(mainPage.getHeaderLogo().isDisplayed(), true);
//	}
//	
//	@Test
//	public void loginFailData() {
//		loginPage.open();
//	    loginPage.logIn("dfdgdg", "12qwAS");
//	    Assert.assertEquals(loginPage.getloginValidation().isDisplayed(), true);
//	}
	
	@Test
	public void addNewProject() throws InterruptedException {
		loginPage.open();
	    loginPage.logIn("admin@tc2014.pl", "12qwAS");
	    mainPage.getAdministrationButton();
	    administrationPage.getAddProjectButton();
	    String name = helper.generateRandomString();
	    String prefix = helper.generateRandomString();
	    administrationPage.setName(name);
	    administrationPage.setPrefix(prefix);
	    administrationPage.getButtonSave();
	    Assert.assertEquals(administrationPage.getpopupProjectAdded().isDisplayed(), true);
	    administrationPage.searchForProject(name);
	    administrationPage.openProject();
	    Assert.assertEquals(projectPage.checkHeader().getText(), "WŁAŚCIWOŚCI PROJEKTU");
	    Assert.assertEquals(projectPage.checkName().getText(), name);
	    Assert.assertEquals(projectPage.checkPrefix().getText(), prefix);
	    Thread.sleep(999);
	}
	


}
