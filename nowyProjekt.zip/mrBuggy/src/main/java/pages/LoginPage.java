package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class LoginPage {
	
	private WebDriver driver;
	private static final String HOME_PAGE_URL = "http://demo.mrbuggy2.testarena.pl/zaloguj";
	
	@FindBy(xpath = "//*[@id='email']")
	private WebElement email;
	
	@FindBy(xpath = "//*[@id='password']")
	private WebElement password;
	
	@FindBy(xpath = "//input[@id='login']")
	private WebElement loginButton;
	
	@FindBy(xpath ="//*[@id='remember']")
	private WebElement rememberMe;
	
	@FindBy(xpath = "//*[@class='login_form_error']")
	private WebElement loginValidation;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		  PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}

	public void open () 
	{
		driver.get(HOME_PAGE_URL);	
	}
	
	public void logIn (String email, String password)
	{	
		setEmail(email);
		setPassword (password);
		this.rememberMe.click();
		pressLoginButton();
	}
	
	public void setEmail(String email)
	{
		this.email.click();
		this.email.sendKeys(email);
	}
	
	public void setPassword(String password)
	{
		this.password.click();
		this.password.sendKeys(password);
	}
	
	public void pressLoginButton() 
	{
		this.loginButton.click();
		
	}
	
	public WebElement getloginValidation ()
	{
		return this.loginValidation;
	}

}
